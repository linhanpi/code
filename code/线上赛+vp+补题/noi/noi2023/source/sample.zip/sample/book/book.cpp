#include<bits/stdc++.h>
#define int long long//信仰
#define ld long double
#define ull unsigned long long
// #define uint unsigned int
// #define rint register int
// #define ll long long
// #define double long double
#define pii pair <int,int>
#define lowbit(x) (-x&x)
#define lson (p<<1)
#define rson (p<<1|1)
using namespace std;
#define read() (red<int>())
template<typename T>inline T red(){T x=0;bool f=false;char c=getchar();while(c<'0'||c>'9'){if(c=='-')f=true;c=getchar();}while(c>='0'&&c<='9')x=(x<<3)+(x<<1)+(c^48),c=getchar();return f?-x:x;}
template<typename T>inline void write(T x){if(x<0){putchar('-');x=-x;}if(x/10)write(x/10);putchar((x%10)^48);return;}
const int N=1e6+5;
const int M=1e2+5;
const int bzt=18;
const int inf=1e18+7;
const int base=131;
const int mod=1e9+7;
const ld eps=1e-6;
const ld alpha=0.75;
const pii lpii={0,0};
const ld MAX_TIME=0.8;
const ld Down=0.996;
mt19937 rnd(time(0));
#define ran_int(l,r) uniform_int_distribution<int>(l,r)(rnd)
#define ran_real(l,r) uniform_real_distribution<ld>(l,r)(rnd)
int mgcd(int x,int y){return x==0?y:mgcd(y%x,x);}
int mlcm(int x,int y){return x/mgcd(x,y)*y;}
inline int qmi(int x,int y,int mod){int ans=1;x%=mod;while(y){if(y&1)ans=ans*x%mod;x=x*x%mod;y>>=1;}return ans;}
inline int fang(int x){return x*x;}
inline int mjia(int x,int y){return (x+y)%mod;}
inline int mjian(int x,int y){return (x-y+mod)%mod;}
inline int mcheng(int x,int y){return (x*y)%mod;}
inline int mchu(int x,int y){return x*qmi(y,mod-2,mod)%mod;}
inline bool dengyu(ld x,ld y){return abs(x-y)<=eps;}
inline bool dayu(ld x,ld y){return x>eps+y;}
inline bool xiaoyu(ld x,ld y){return y>eps+x;}
int w[N],ww[N],mm[N],mo[N];
bool vis[N];
int ans,res;
int n;
void dfs(int now){
    if(now==n){
        ans=min(ans,res);
        return;
    }
    int ret=res;
    for(int i=1;i<=n;i++){
        if(vis[i])continue;
        for(int j=i+1;j<=n;j++){
            if(vis[j])continue;
            res+=min(w[i],w[j])+mo[i]+mo[j];
            pii t1={w[i],mo[i]},t2={w[j],mo[j]};
            if(res>=ans){
                res=ret;
                continue;
            }
            w[i]+=w[j];
            mo[i]=2*max(mo[i],mo[j])+1;
            vis[j]=1;
            dfs(now+1);
            vis[j]=0;
            w[i]=t1.first,w[j]=t2.first;
            mo[i]=t1.second,mo[j]=t2.second;
            res=ret;
        }
    }
    return ;
}
int fa[N];
vector <int> v[N];
void dfss(int now){
    ww[now]=w[now],mm[now]=0;
    for(int y:v[now]){
        dfss(y);
        res+=min(ww[now],ww[y])+mm[now]+mm[y];
        ww[now]+=ww[y];
        mm[now]=2*max(mm[now],mm[y])+1;
    }
    return ;
}
void js(){
    for(int i=1;i<=n;i++)v[i].clear();
    for(int i=2;i<=n;i++){
        v[fa[i]].push_back(i);
    }
    res=0;
    dfss(1);
    return ;
}
int ti;
void sa(){
	double t=100000;
	while(t>1e-15){
        // cout<<ran_int(1,2)<<endl;
        if(ran_int(1,2)&1){
            int i=ran_int(2,n);
            int j=ran_int(1,i-1);
            int tp=fa[i];
            fa[i]=j;
            js();
            int cha=ans-res;
		    if(cha>0){
		    	ans=res;
		    }
            else if(exp(1.0*cha/t)<=ran_real(0,1)){
                fa[i]=tp;
		    }
        }
		else{
            int i=ran_int(1,n-1);
            int j=ran_int(i+1,n);
            swap(w[i],w[j]);
            js();
            int cha=ans-res;
		    if(cha>0){
		    	ans=res;
		    }
            else if(exp(1.0*cha/t)<=ran_real(0,1)){
                swap(w[i],w[j]);
		    }
        }
		t*=Down;
	}
	return ;
}
int T;
void work(){
    while(clock()-ti<CLOCKS_PER_SEC*1.4/10){
        // for(int i=2;i<=n;i++){
        //     fa[i]=ran_int(1,i-1);
        // }
        // for(int k=1;k<=n*n;k++){
        //     int i=ran_int(1,n-1);
        //     int j=ran_int(i+1,n);
        //     swap(w[i],w[j]);
        // }
        sa();
    }
    return ;
}
signed main(){
    freopen("book.in","r",stdin);
    freopen("book.out","w",stdout);
	T=read();
    while(T--){
        ti=clock();
        n=read();
        for(int i=1;i<=n;i++){
            w[i]=read();
        }
        sort(w+1,w+n+1);
        if(n<=7){
            ans=inf,res=0;
            dfs(1);
            cout<<ans<<endl;
            continue;
        }
        else{
            ans=inf;
            for(int i=2;i<=n;i++){
                fa[i]=ran_int(1,i-1);
            }
            for(int k=1;k<=n*n;k++){
                int i=ran_int(1,n-1);
                int j=ran_int(i+1,n);
                swap(w[i],w[j]);
            }
            work();
            cout<<ans<<endl;
            continue;
        }
        
    }
	return 0;
}
