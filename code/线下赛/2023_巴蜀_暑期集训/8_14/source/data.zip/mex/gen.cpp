
int n,k,w,m,A[N];
unsigned long long seed;
unsigned long long _rand(){
	seed^=seed<<13;
	seed^=seed>>7;
	seed^=seed<<17;
	return seed;
}
void read_test(){
    scanf("%d%d%d%llu",&k,&w,&m,&seed);
    for(int i=1;i<=n;++i) A[i]=_rand()%m;
}
