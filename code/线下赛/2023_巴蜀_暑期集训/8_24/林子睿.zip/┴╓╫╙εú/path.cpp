#include<bits/stdc++.h>
#define int long long//信仰
#define ld long double
#define uint unsigned long long
// #define uint unsigned int
// #define rint register int
// #define int long long
// #define double long double
#define pii pair <int,int>
#define lowbit(x) (-x&x)
#define lson (p<<1)
#define rson (p<<1|1)
using namespace std;
#define read() (red<int>())
template<typename T>inline T red(){T x=0;bool f=false;char c=getchar();while(c<'0'||c>'9'){if(c=='-')f=true;c=getchar();}while(c>='0'&&c<='9')x=(x<<3)+(x<<1)+(c^48),c=getchar();return f?-x:x;}
template<typename T>inline void write(T x){if(x<0){putchar('-');x=-x;}if(x/10)write(x/10);putchar((x%10)^48);return;}
const int N=1e6+5;
const int M=1e2+5;
const int bzt=18;
const int inf=INT_MAX;
const int base=131;
const int mod=1e9+9;
const ld eps=1e-6;
const ld alpha=0.75;
const pii lpii={0,0};
const ld MAX_TIME=0.8;
const ld Down=0.996;
// mt19937 rnd(time(0));
// #define ran_int(l,r) uniform_int_distribution<int>(l,r)(rnd)
// #define ran_real(l,r) uniform_real_distribution<ld>(l,r)(rnd)
int mgcd(int x,int y){return x==0?y:mgcd(y%x,x);}
int mlcm(int x,int y){return x/mgcd(x,y)*y;}
inline int qmi(int x,int y,int mod){int ans=1;x%=mod;while(y){if(y&1)ans=ans*x%mod;x=x*x%mod;y>>=1;}return ans;}
inline int fang(int x){return x*x;}
inline int mjia(int x,int y){return (x+y)%mod;}
inline int mjian(int x,int y){return (x-y+mod)%mod;}
inline int mcheng(int x,int y){return (x*y)%mod;}
inline int mchu(int x,int y){return x*qmi(y,mod-2,mod)%mod;}
inline bool dengyu(ld x,ld y){return abs(x-y)<=eps;}
inline bool dayu(ld x,ld y){return x>eps+y;}
inline bool xiaoyu(ld x,ld y){return y>eps+x;}
int n,m,S,T;
int head[2005],ver[30005],nxt[30005];
int edge[30005];
int tot;
void add(int x,int y,int z){
	ver[++tot]=y,edge[tot]=z;
	nxt[tot]=head[x],head[x]=tot;
	return;
}
struct node{
	int x;
	int y;
	bool operator < (const node &w) const{
		return y>w.y;
	}
};
int dist[2005];
bool vis[2005];
priority_queue <node> q;
void dijkstra(){
	memset(dist,0x3f,sizeof(dist));
	dist[S]=0;
	q.push({S,0});
	while(!q.empty()){
		node tmp=q.top();
		q.pop();
		int x=tmp.x;
		if(vis[x]) continue;
		vis[x]=1;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(dist[y]>dist[x]+edge[i]){
				dist[y]=dist[x]+edge[i];
				if(!vis[y]) q.push({y,dist[y]});
			}
		}
	}
	return;
}
int p[2005];
bool cmp(int x,int y){
	return dist[x]<dist[y];
}
int f[2005][2005];
bool mp[2005][2005];
vector <int> G[2005];
signed main(){
	freopen("path.in","r",stdin);
	freopen("path.out","w",stdout);
	n=read(),m=read(),S=read(),T=read();
	for(int i=1;i<=m;++i){
		int x=read(),y=read(),z=read();
		add(x,y,z);
	}
	dijkstra();
	for(int i=1;i<=n;++i) p[i]=i;
	sort(p+1,p+n+1,cmp);
	for(int x=1;x<=n;++x){
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(mp[x][y]) continue;
			if(dist[y]==dist[x]+edge[i]){
				mp[x][y]=1;
				G[x].push_back(y);
			}
		}
	}
	f[S][S]=1;
    int flag=0;
    for(int x:G[S]){
		for(int y:G[S]){
			if(x==T&&y==T){
                flag=1;
            }
            else f[x][y]=f[y][x]=1;
		}
	}
	for(int i=2;i<=n;++i){
		int x=p[i];
		for(int j=2;j<=n;++j){
			if(i!=1&&j==i) continue;
			int y=p[j];
			if(dist[x]<dist[y]){
				for(int z:G[x]){
					f[z][y]=(f[z][y]+f[x][y])%mod;
				}
			}
			else{
				for(int z:G[y]){
					f[x][z]=(f[x][z]+f[x][y])%mod;
				}
			}
		}
	}
	cout<<(f[T][T]*qmi(2,mod-2,mod)%mod+flag)%mod;
	
	return 0;
}
/*



*/
