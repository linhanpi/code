#include<bits/stdc++.h>
#define int long long//信仰
#define ld long double
#define ull unsigned long long
// #define uint unsigned int
// #define rint register int
// #define ll long long
// #define double long double
#define pii pair <int,int>
#define lowbit(x) (-x&x)
#define lson (p<<1)
#define rson (p<<1|1)
using namespace std;
#define read() (red<int>())
template<typename T>inline T red(){T x=0;bool f=false;char c=getchar();while(c<'0'||c>'9'){if(c=='-')f=true;c=getchar();}while(c>='0'&&c<='9')x=(x<<3)+(x<<1)+(c^48),c=getchar();return f?-x:x;}
template<typename T>inline void write(T x){if(x<0){putchar('-');x=-x;}if(x/10)write(x/10);putchar((x%10)^48);return;}
const int N=2e5+5;
const int M=1e2+5;
const int bzt=18;
const int inf=1e12+7;
const int base=131;
const int mod=1e9+7;
const ld eps=1e-6;
const ld alpha=0.75;
const pii lpii={0,0};
const ld MAX_TIME=0.8;
const ld Down=0.996;
mt19937 rnd(time(0));
#define ran_int(l,r) uniform_int_distribution<int>(l,r)(rnd)
#define ran_real(l,r) uniform_real_distribution<ld>(l,r)(rnd)
int mgcd(int x,int y){return x==0?y:mgcd(y%x,x);}
int mlcm(int x,int y){return x/mgcd(x,y)*y;}
inline int qmi(int x,int y,int mod){int ans=1;x%=mod;while(y){if(y&1)ans=ans*x%mod;x=x*x%mod;y>>=1;}return ans;}
inline int fang(int x){return x*x;}
inline int mjia(int x,int y){return (x+y)%mod;}
inline int mjian(int x,int y){return (x-y+mod)%mod;}
inline int mcheng(int x,int y){return (x*y)%mod;}
inline int mchu(int x,int y){return x*qmi(y,mod-2,mod)%mod;}
inline bool dengyu(ld x,ld y){return abs(x-y)<=eps;}
inline bool dayu(ld x,ld y){return x>eps+y;}
inline bool xiaoyu(ld x,ld y){return y>eps+x;}
int n,q,L;
vector<int> v[N];
int fa[N],w[N][5],dp[N][5],res[N];
void dfs(int x){
	if(dp[x][1]>-inf) return;
	int sum=0;
	for(int y:v[x]){
		dfs(y);
		int tmp=-inf;
		for(int k=1;k<=L;k++){
			tmp=max(tmp,dp[y][k]);
		}
		res[y]=tmp;
		sum+=tmp;
	}
	dp[x][1]=sum+w[x][1];
	for(int k=2;k<=L;k++){
		for(int y:v[x]){
			dp[x][k]=max(dp[x][k],dp[y][k-1]+sum-res[y]+w[x][k]);
		} 
	}
	return ;
}
signed main(){
	freopen("decompose.in","r",stdin);
	freopen("decompose.out","w",stdout);
    memset(dp,-0x3f,sizeof(dp));
	n=read(),q=read(),L=read();
	for(int i=2;i<=n;i++){
		int x=read();
		v[x].push_back(i);fa[i]=x;
	}
	for(int i=1;i<=n;i++){
        for(int j=1;j<=L;j++){
            w[i][j]=read();
        }
    }
	while(q--){
		int x=read();
		for(int i=1;i<=L;i++){
            w[x][i]=read();
        }
		for(int now=x;now;now=fa[now]){
            memset(dp[now],-0x3f,sizeof(dp[now]));
        }
		dfs(1);
		int ans=-inf;
		for(int i=1;i<=L;i++)ans=max(ans,dp[1][i]);
        write(ans);
        puts("");
	}
	return 0;
}