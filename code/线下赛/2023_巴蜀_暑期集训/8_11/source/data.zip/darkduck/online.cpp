unsigned lans=0;
for(int i=1;i<=q;++i){
	int l,r;
	std::cin>>l>>r;
	if(tp==1){
		l=(l+lans)%m+1;
		r=(r+lans)%m+1;
		if(l>r) std::swap(l,r);
	}
	//solve
	lans<<=1;
	if(Answer_Is_Yes) ++lans;
}
